const app = require('./api/index.js');

module.exports = app;