// متغيرات عامة
let currentUser = null;
let isAuthenticated = false;

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    console.log('🚀 تهيئة نظام إدارة الاستثمار العقاري...');
    
    // إعداد الواجهة
    setupUI();
    
    // التحقق من حالة تسجيل الدخول
    checkAuthStatus();
    
    // إعداد الأحداث
    setupEventListeners();
});

// إعداد الواجهة
function setupUI() {
    console.log('🎨 إعداد الواجهة...');
    
    // إخفاء جميع الأقسام
    hideAllSections();
    
    // إظهار شاشة تسجيل الدخول
    showLoginScreen();
}

// إعداد الأحداث
function setupEventListeners() {
    // حدث تسجيل الدخول
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // حدث تسجيل الخروج
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }
    
    // أحداث التنقل
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const section = this.getAttribute('data-section');
            showSection(section);
        });
    });
}

// التحقق من حالة تسجيل الدخول
function checkAuthStatus() {
    const token = localStorage.getItem('authToken');
    if (token) {
        isAuthenticated = true;
        currentUser = JSON.parse(localStorage.getItem('user') || '{}');
        showMainApp();
    }
}

// معالجة تسجيل الدخول
async function handleLogin(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.success) {
            // حفظ بيانات المستخدم
            localStorage.setItem('authToken', data.token);
            localStorage.setItem('user', JSON.stringify(data.user));
            
            currentUser = data.user;
            isAuthenticated = true;
            
            showMainApp();
            loadDashboard();
        } else {
            alert('خطأ في تسجيل الدخول: ' + data.message);
        }
    } catch (error) {
        console.error('خطأ في تسجيل الدخول:', error);
        alert('خطأ في الاتصال بالخادم');
    }
}

// معالجة تسجيل الخروج
function handleLogout() {
    localStorage.removeItem('authToken');
    localStorage.removeItem('user');
    isAuthenticated = false;
    currentUser = null;
    showLoginScreen();
}

// إظهار شاشة تسجيل الدخول
function showLoginScreen() {
    hideAllSections();
    document.getElementById('loginScreen').style.display = 'block';
}

// إظهار التطبيق الرئيسي
function showMainApp() {
    hideAllSections();
    document.getElementById('mainApp').style.display = 'block';
    updateUserInfo();
}

// إخفاء جميع الأقسام
function hideAllSections() {
    const sections = ['loginScreen', 'mainApp', 'dashboard', 'customers', 'units', 'contracts', 'reports'];
    sections.forEach(section => {
        const element = document.getElementById(section);
        if (element) {
            element.style.display = 'none';
        }
    });
}

// إظهار قسم معين
function showSection(sectionName) {
    hideAllSections();
    document.getElementById('mainApp').style.display = 'block';
    
    const section = document.getElementById(sectionName);
    if (section) {
        section.style.display = 'block';
        loadSectionData(sectionName);
    }
}

// تحديث معلومات المستخدم
function updateUserInfo() {
    const userInfo = document.getElementById('userInfo');
    if (userInfo && currentUser) {
        userInfo.textContent = `مرحباً، ${currentUser.name}`;
    }
}

// تحميل بيانات القسم
async function loadSectionData(sectionName) {
    switch(sectionName) {
        case 'dashboard':
            await loadDashboard();
            break;
        case 'customers':
            await loadCustomers();
            break;
        case 'units':
            await loadUnits();
            break;
        case 'contracts':
            await loadContracts();
            break;
        case 'reports':
            await loadReports();
            break;
    }
}

// تحميل لوحة التحكم
async function loadDashboard() {
    try {
        const response = await fetch('/api/reports');
        const data = await response.json();
        
        if (data.success) {
            updateDashboard(data.data);
        }
    } catch (error) {
        console.error('خطأ في تحميل لوحة التحكم:', error);
    }
}

// تحديث لوحة التحكم
function updateDashboard(data) {
    const dashboard = document.getElementById('dashboard');
    if (dashboard) {
        dashboard.innerHTML = `
            <div class="dashboard-grid">
                <div class="stat-card">
                    <h3>إجمالي العملاء</h3>
                    <p class="stat-number">${data.total_customers}</p>
                </div>
                <div class="stat-card">
                    <h3>إجمالي الوحدات</h3>
                    <p class="stat-number">${data.total_units}</p>
                </div>
                <div class="stat-card">
                    <h3>إجمالي العقود</h3>
                    <p class="stat-number">${data.total_contracts}</p>
                </div>
                <div class="stat-card">
                    <h3>إجمالي الإيرادات</h3>
                    <p class="stat-number">${data.total_revenue.toLocaleString()} ريال</p>
                </div>
            </div>
        `;
    }
}

// تحميل العملاء
async function loadCustomers() {
    try {
        const response = await fetch('/api/customers');
        const data = await response.json();
        
        if (data.success) {
            updateCustomersTable(data.data);
        }
    } catch (error) {
        console.error('خطأ في تحميل العملاء:', error);
    }
}

// تحديث جدول العملاء
function updateCustomersTable(customers) {
    const customersSection = document.getElementById('customers');
    if (customersSection) {
        customersSection.innerHTML = `
            <h2>إدارة العملاء</h2>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>الاسم</th>
                            <th>الهاتف</th>
                            <th>البريد الإلكتروني</th>
                            <th>العنوان</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${customers.map(customer => `
                            <tr>
                                <td>${customer.name}</td>
                                <td>${customer.phone}</td>
                                <td>${customer.email}</td>
                                <td>${customer.address}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }
}

// تحميل الوحدات
async function loadUnits() {
    try {
        const response = await fetch('/api/units');
        const data = await response.json();
        
        if (data.success) {
            updateUnitsTable(data.data);
        }
    } catch (error) {
        console.error('خطأ في تحميل الوحدات:', error);
    }
}

// تحديث جدول الوحدات
function updateUnitsTable(units) {
    const unitsSection = document.getElementById('units');
    if (unitsSection) {
        unitsSection.innerHTML = `
            <h2>إدارة الوحدات</h2>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>اسم الوحدة</th>
                            <th>النوع</th>
                            <th>المساحة</th>
                            <th>السعر</th>
                            <th>الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${units.map(unit => `
                            <tr>
                                <td>${unit.name}</td>
                                <td>${unit.type}</td>
                                <td>${unit.area} م²</td>
                                <td>${unit.price.toLocaleString()} ريال</td>
                                <td>${unit.status}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }
}

// تحميل العقود
async function loadContracts() {
    try {
        const response = await fetch('/api/contracts');
        const data = await response.json();
        
        if (data.success) {
            updateContractsTable(data.data);
        }
    } catch (error) {
        console.error('خطأ في تحميل العقود:', error);
    }
}

// تحديث جدول العقود
function updateContractsTable(contracts) {
    const contractsSection = document.getElementById('contracts');
    if (contractsSection) {
        contractsSection.innerHTML = `
            <h2>إدارة العقود</h2>
            <div class="table-container">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>رقم العقد</th>
                            <th>تاريخ البداية</th>
                            <th>تاريخ الانتهاء</th>
                            <th>المبلغ الإجمالي</th>
                            <th>الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                        ${contracts.map(contract => `
                            <tr>
                                <td>${contract.id}</td>
                                <td>${contract.start_date}</td>
                                <td>${contract.end_date}</td>
                                <td>${contract.total_amount.toLocaleString()} ريال</td>
                                <td>${contract.status}</td>
                            </tr>
                        `).join('')}
                    </tbody>
                </table>
            </div>
        `;
    }
}

// تحميل التقارير
async function loadReports() {
    try {
        const response = await fetch('/api/reports');
        const data = await response.json();
        
        if (data.success) {
            updateReportsSection(data.data);
        }
    } catch (error) {
        console.error('خطأ في تحميل التقارير:', error);
    }
}

// تحديث قسم التقارير
function updateReportsSection(data) {
    const reportsSection = document.getElementById('reports');
    if (reportsSection) {
        reportsSection.innerHTML = `
            <h2>التقارير المالية</h2>
            <div class="reports-grid">
                <div class="report-card">
                    <h3>تقرير الإيرادات الشهرية</h3>
                    <div class="report-content">
                        ${data.monthly_stats.map(stat => `
                            <div class="stat-item">
                                <span>${stat.month}:</span>
                                <span>${stat.revenue.toLocaleString()} ريال</span>
                            </div>
                        `).join('')}
                    </div>
                </div>
            </div>
        `;
    }
}

console.log('✅ تم تحميل نظام إدارة الاستثمار العقاري بنجاح!');