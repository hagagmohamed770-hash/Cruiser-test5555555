// متغيرات عامة
let currentUser = null;
let authToken = localStorage.getItem('authToken');
let currentSection = 'dashboard';

// تهيئة التطبيق
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
});

// تهيئة التطبيق
function initializeApp() {
    // التحقق من المصادقة
    if (authToken) {
        verifyToken();
    } else {
        showLoginScreen();
    }

    // إعداد مستمعي الأحداث
    setupEventListeners();
    
    // تحميل الإعدادات
    loadSettings();
}

// إعداد مستمعي الأحداث
function setupEventListeners() {
    // تسجيل الدخول
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    // تسجيل الخروج
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('submit', handleLogout);
    }

    // التنقل
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', handleNavigation);
    });

    // تبديل الشريط الجانبي
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }

    // اختيار المظهر
    const themeSelector = document.getElementById('themeSelector');
    if (themeSelector) {
        themeSelector.addEventListener('change', handleThemeChange);
    }

    // اختيار الخط
    const fontSelector = document.getElementById('fontSelector');
    if (fontSelector) {
        fontSelector.addEventListener('change', handleFontChange);
    }

    // البحث والفلترة
    setupSearchAndFilters();

    // النوافذ المنبثقة
    setupModals();
}

// التحقق من صحة التوكن
async function verifyToken() {
    try {
        showLoading();
        const response = await fetch('/api/auth/verify', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            currentUser = data.user;
            showMainApp();
            loadDashboard();
        } else {
            localStorage.removeItem('authToken');
            showLoginScreen();
        }
    } catch (error) {
        console.error('خطأ في التحقق من التوكن:', error);
        localStorage.removeItem('authToken');
        showLoginScreen();
    } finally {
        hideLoading();
    }
}

// معالجة تسجيل الدخول
async function handleLogin(event) {
    event.preventDefault();
    
    const formData = new FormData(event.target);
    const username = formData.get('username');
    const password = formData.get('password');

    try {
        showLoading();
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });

        const data = await response.json();

        if (response.ok) {
            authToken = data.token;
            currentUser = data.user;
            localStorage.setItem('authToken', authToken);
            showMainApp();
            loadDashboard();
            showNotification('تم تسجيل الدخول بنجاح', 'success');
        } else {
            showNotification(data.message || 'خطأ في تسجيل الدخول', 'error');
        }
    } catch (error) {
        console.error('خطأ في تسجيل الدخول:', error);
        showNotification('خطأ في الاتصال بالخادم', 'error');
    } finally {
        hideLoading();
    }
}

// معالجة تسجيل الخروج
function handleLogout() {
    localStorage.removeItem('authToken');
    authToken = null;
    currentUser = null;
    showLoginScreen();
    showNotification('تم تسجيل الخروج بنجاح', 'success');
}

// إظهار شاشة تسجيل الدخول
function showLoginScreen() {
    document.getElementById('loginScreen').style.display = 'flex';
    document.getElementById('app').style.display = 'none';
}

// إظهار التطبيق الرئيسي
function showMainApp() {
    document.getElementById('loginScreen').style.display = 'none';
    document.getElementById('app').style.display = 'flex';
}

// معالجة التنقل
function handleNavigation(event) {
    event.preventDefault();
    
    const section = event.currentTarget.dataset.section;
    if (section) {
        navigateToSection(section);
    }
}

// الانتقال إلى قسم معين
function navigateToSection(section) {
    // إزالة الفئة النشطة من جميع الروابط
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });

    // إضافة الفئة النشطة للرابط المحدد
    const activeLink = document.querySelector(`[data-section="${section}"]`);
    if (activeLink) {
        activeLink.classList.add('active');
    }

    // إخفاء جميع الأقسام
    document.querySelectorAll('.page-section').forEach(page => {
        page.classList.remove('active');
    });

    // إظهار القسم المحدد
    const targetSection = document.getElementById(section);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    // تحديث عنوان الصفحة
    updatePageTitle(section);

    // تحميل البيانات حسب القسم
    loadSectionData(section);

    currentSection = section;
}

// تحديث عنوان الصفحة
function updatePageTitle(section) {
    const titles = {
        dashboard: 'لوحة التحكم',
        customers: 'إدارة العملاء',
        units: 'إدارة الوحدات',
        contracts: 'إدارة العقود',
        installments: 'إدارة الأقساط',
        partners: 'إدارة الشركاء',
        brokers: 'إدارة السماسرة',
        vouchers: 'إدارة الإيصالات',
        treasury: 'إدارة الخزينة',
        reports: 'التقارير',
        audit: 'سجل التغييرات',
        backups: 'النسخ الاحتياطية'
    };

    const pageTitle = document.getElementById('pageTitle');
    if (pageTitle) {
        pageTitle.textContent = titles[section] || 'النظام';
    }
}

// تحميل بيانات القسم
function loadSectionData(section) {
    switch (section) {
        case 'dashboard':
            loadDashboard();
            break;
        case 'customers':
            loadCustomers();
            break;
        case 'units':
            loadUnits();
            break;
        case 'contracts':
            loadContracts();
            break;
        case 'installments':
            loadInstallments();
            break;
        case 'partners':
            loadPartners();
            break;
        case 'brokers':
            loadBrokers();
            break;
        case 'vouchers':
            loadVouchers();
            break;
        case 'treasury':
            loadTreasury();
            break;
        case 'reports':
            loadReports();
            break;
        case 'audit':
            loadAudit();
            break;
        case 'backups':
            loadBackups();
            break;
    }
}

// تحميل لوحة التحكم
async function loadDashboard() {
    try {
        showLoading();
        const response = await fetch('/api/reports/dashboard', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateDashboardStats(data);
        }
    } catch (error) {
        console.error('خطأ في تحميل لوحة التحكم:', error);
        showNotification('خطأ في تحميل البيانات', 'error');
    } finally {
        hideLoading();
    }
}

// تحديث إحصائيات لوحة التحكم
function updateDashboardStats(data) {
    // تحديث الأرقام الإجمالية
    document.getElementById('totalCustomers').textContent = data.totalCustomers || 0;
    document.getElementById('totalUnits').textContent = data.totalUnits || 0;
    document.getElementById('totalContracts').textContent = data.totalContracts || 0;
    document.getElementById('totalRevenue').textContent = formatCurrency(data.totalRevenue || 0);

    // تحديث الأقساط المتأخرة
    const overdueContainer = document.getElementById('overdueInstallments');
    if (overdueContainer && data.overdueInstallments) {
        overdueContainer.innerHTML = data.overdueInstallments.map(installment => `
            <div class="overdue-item">
                <strong>${installment.customer_name}</strong>
                <span>${formatCurrency(installment.amount)}</span>
                <small>${formatDate(installment.due_date)}</small>
            </div>
        `).join('');
    }

    // تحديث الإحصائيات الأخيرة
    const recentContainer = document.getElementById('recentStats');
    if (recentContainer && data.recentStats) {
        recentContainer.innerHTML = data.recentStats.map(stat => `
            <div class="stat-item">
                <span class="stat-label">${stat.label}</span>
                <span class="stat-value">${stat.value}</span>
            </div>
        `).join('');
    }
}

// تحميل العملاء
async function loadCustomers() {
    try {
        showLoading();
        const response = await fetch('/api/customers', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            renderCustomersTable(data.customers || []);
        }
    } catch (error) {
        console.error('خطأ في تحميل العملاء:', error);
        showNotification('خطأ في تحميل البيانات', 'error');
    } finally {
        hideLoading();
    }
}

// عرض جدول العملاء
function renderCustomersTable(customers) {
    const tbody = document.getElementById('customersTableBody');
    if (!tbody) return;

    tbody.innerHTML = customers.map(customer => `
        <tr>
            <td>${customer.name}</td>
            <td>${customer.phone || '-'}</td>
            <td>${customer.email || '-'}</td>
            <td>${customer.address || '-'}</td>
            <td>
                <span class="status-badge ${customer.status}">
                    ${getStatusText(customer.status)}
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editCustomer(${customer.id})">
                    تعديل
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteCustomer(${customer.id})">
                    حذف
                </button>
            </td>
        </tr>
    `).join('');
}

// تحميل الوحدات
async function loadUnits() {
    try {
        showLoading();
        const response = await fetch('/api/units', {
            headers: {
                'Authorization': `Bearer ${authToken}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            renderUnitsTable(data.units || []);
        }
    } catch (error) {
        console.error('خطأ في تحميل الوحدات:', error);
        showNotification('خطأ في تحميل البيانات', 'error');
    } finally {
        hideLoading();
    }
}

// عرض جدول الوحدات
function renderUnitsTable(units) {
    const tbody = document.getElementById('unitsTableBody');
    if (!tbody) return;

    tbody.innerHTML = units.map(unit => `
        <tr>
            <td>${unit.name}</td>
            <td>${getUnitTypeText(unit.type)}</td>
            <td>${unit.area ? unit.area + ' م²' : '-'}</td>
            <td>${formatCurrency(unit.price)}</td>
            <td>${unit.location || '-'}</td>
            <td>
                <span class="status-badge ${unit.status}">
                    ${getUnitStatusText(unit.status)}
                </span>
            </td>
            <td>
                <button class="btn btn-sm btn-primary" onclick="editUnit(${unit.id})">
                    تعديل
                </button>
                <button class="btn btn-sm btn-danger" onclick="deleteUnit(${unit.id})">
                    حذف
                </button>
            </td>
        </tr>
    `).join('');
}

// دوال مساعدة للنصوص
function getStatusText(status) {
    const statuses = {
        'active': 'نشط',
        'inactive': 'غير نشط'
    };
    return statuses[status] || status;
}

function getUnitTypeText(type) {
    const types = {
        'apartment': 'شقة',
        'villa': 'فيلا',
        'office': 'مكتب',
        'shop': 'محل'
    };
    return types[type] || type;
}

function getUnitStatusText(status) {
    const statuses = {
        'available': 'متاح',
        'sold': 'مباع',
        'rented': 'مؤجر'
    };
    return statuses[status] || status;
}

// تنسيق العملة
function formatCurrency(amount) {
    return new Intl.NumberFormat('ar-SA', {
        style: 'currency',
        currency: 'SAR'
    }).format(amount);
}

// تنسيق التاريخ
function formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('ar-SA');
}

// إظهار/إخفاء مؤشر التحميل
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'flex';
    }
}

function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

// إظهار الإشعارات
function showNotification(message, type = 'info') {
    const notifications = document.getElementById('notifications');
    if (!notifications) return;

    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;

    notifications.appendChild(notification);

    // إزالة الإشعار بعد 5 ثوان
    setTimeout(() => {
        notification.remove();
    }, 5000);
}

// تبديل الشريط الجانبي
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    if (sidebar) {
        sidebar.classList.toggle('show');
    }
}

// معالجة تغيير المظهر
function handleThemeChange(event) {
    const theme = event.target.value;
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
}

// معالجة تغيير الخط
function handleFontChange(event) {
    const font = event.target.value;
    document.documentElement.setAttribute('data-font', font);
    localStorage.setItem('font', font);
}

// تحميل الإعدادات
function loadSettings() {
    const theme = localStorage.getItem('theme') || 'light';
    const font = localStorage.getItem('font') || 'normal';

    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-font', font);

    const themeSelector = document.getElementById('themeSelector');
    const fontSelector = document.getElementById('fontSelector');

    if (themeSelector) themeSelector.value = theme;
    if (fontSelector) fontSelector.value = font;
}

// إعداد البحث والفلترة
function setupSearchAndFilters() {
    // البحث في العملاء
    const customerSearch = document.getElementById('customerSearch');
    if (customerSearch) {
        customerSearch.addEventListener('input', debounce(filterCustomers, 300));
    }

    // البحث في الوحدات
    const unitSearch = document.getElementById('unitSearch');
    if (unitSearch) {
        unitSearch.addEventListener('input', debounce(filterUnits, 300));
    }

    // فلترة العملاء
    const customerStatusFilter = document.getElementById('customerStatusFilter');
    if (customerStatusFilter) {
        customerStatusFilter.addEventListener('change', filterCustomers);
    }

    // فلترة الوحدات
    const unitTypeFilter = document.getElementById('unitTypeFilter');
    const unitStatusFilter = document.getElementById('unitStatusFilter');
    
    if (unitTypeFilter) {
        unitTypeFilter.addEventListener('change', filterUnits);
    }
    if (unitStatusFilter) {
        unitStatusFilter.addEventListener('change', filterUnits);
    }
}

// فلترة العملاء
function filterCustomers() {
    // سيتم تنفيذها لاحقاً
    console.log('فلترة العملاء');
}

// فلترة الوحدات
function filterUnits() {
    // سيتم تنفيذها لاحقاً
    console.log('فلترة الوحدات');
}

// إعداد النوافذ المنبثقة
function setupModals() {
    // إغلاق النوافذ المنبثقة
    document.querySelectorAll('.modal-close, .modal-cancel').forEach(button => {
        button.addEventListener('click', closeModal);
    });

    // إغلاق النافذة المنبثقة عند النقر خارجها
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', (e) => {
            if (e.target === modal) {
                closeModal();
            }
        });
    });

    // إضافة مستمعي الأحداث لأزرار الإضافة
    const addCustomerBtn = document.getElementById('addCustomerBtn');
    if (addCustomerBtn) {
        addCustomerBtn.addEventListener('click', () => showCustomerModal());
    }

    const addUnitBtn = document.getElementById('addUnitBtn');
    if (addUnitBtn) {
        addUnitBtn.addEventListener('click', () => showUnitModal());
    }
}

// إظهار نافذة العميل
function showCustomerModal(customerId = null) {
    const modal = document.getElementById('customerModal');
    const title = document.getElementById('customerModalTitle');
    const form = document.getElementById('customerForm');

    if (customerId) {
        title.textContent = 'تعديل العميل';
        loadCustomerData(customerId);
    } else {
        title.textContent = 'إضافة عميل جديد';
        form.reset();
    }

    modal.classList.add('show');
}

// إظهار نافذة الوحدة
function showUnitModal(unitId = null) {
    const modal = document.getElementById('unitModal');
    const title = document.getElementById('unitModalTitle');
    const form = document.getElementById('unitForm');

    if (unitId) {
        title.textContent = 'تعديل الوحدة';
        loadUnitData(unitId);
    } else {
        title.textContent = 'إضافة وحدة جديدة';
        form.reset();
    }

    modal.classList.add('show');
}

// إغلاق النافذة المنبثقة
function closeModal() {
    document.querySelectorAll('.modal').forEach(modal => {
        modal.classList.remove('show');
    });
}

// دالة debounce
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// دوال placeholder للوظائف المتبقية
function loadContracts() {
    console.log('تحميل العقود');
}

function loadInstallments() {
    console.log('تحميل الأقساط');
}

function loadPartners() {
    console.log('تحميل الشركاء');
}

function loadBrokers() {
    console.log('تحميل السماسرة');
}

function loadVouchers() {
    console.log('تحميل الإيصالات');
}

function loadTreasury() {
    console.log('تحميل الخزينة');
}

function loadReports() {
    console.log('تحميل التقارير');
}

function loadAudit() {
    console.log('تحميل سجل التغييرات');
}

function loadBackups() {
    console.log('تحميل النسخ الاحتياطية');
}

function editCustomer(id) {
    console.log('تعديل العميل:', id);
    showCustomerModal(id);
}

function deleteCustomer(id) {
    console.log('حذف العميل:', id);
}

function editUnit(id) {
    console.log('تعديل الوحدة:', id);
    showUnitModal(id);
}

function deleteUnit(id) {
    console.log('حذف الوحدة:', id);
}

function loadCustomerData(id) {
    console.log('تحميل بيانات العميل:', id);
}

function loadUnitData(id) {
    console.log('تحميل بيانات الوحدة:', id);
}